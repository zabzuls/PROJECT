<?php
 
 include "koneksi.php";
 $sql = "SELECT * FROM bahasa";
 $hasil = mysqli_query($kon,$sql);
 $jumlah = mysqli_num_rows($hasil);
 
 if(!$hasil)
    die("Gagal Query");

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="./customStyle.css">
    <title>ZullCourse</title>
  </head>
  <body>
    <div class="container-sm">
      <div
        class="bg-white d-inline shadow-sm fixed-top rounded-0 d-flex justify-content-between"
      >
          <a href="akun.php">
          <!--<img src="icon/zabzul.png" width="70rem" alt="akun">-->
          <div class="kosong"></div>
          <p class="logo mt-4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ZabzulSupratman</p>
          </a>
        <a class="p-4" href="cari.php"
          ><img src="./icon/search.png" width="23rem"
        /></a>
      </div>
      <br />
      <br />
      <h1 class="text-center mt-5">ZullCourse</h1>
      <table class="table table-primary table-striped" id="baca">
        <tr>
          <th>NO</th>
          <th>KATA</th>
          <th>ARTINYA</th>
        </tr>
        <?php
        $no = 0;
         while ($row = mysqli_fetch_assoc($hasil)){
          $no++;
            echo "<tr>";
            echo "<td>".$no."</td>";
            echo "<td>".$row['bhs_inggris']."</td>";
            echo "<td>".$row['bhs_indonesia']."</td>";
            echo "</tr>";
          }
        ?>
      </table>
    </div>
    <br/>

    <!-- batas -->
    <div
      class="bg-white d-inline shadow-lg fixed-bottom rounded-0 d-flex justify-content-evenly p-2 mt-sm-5"
    >
      <a href="index.php"
        ><img src="icon/home.png" width="23rem" alt="utama"
      /></a>
      <a href="#baca"><img src="icon/book.png" width="23rem" alt="utama" /></a>
      <a href="tambah.php"
        ><img src="icon/add.png" width="23rem" alt="tambah"
      /></a>
      <a href="https://zabzuls.github.io/"
        ><img src="icon/user.png" width="23rem" alt="akun"
      /></a>
    </div>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
