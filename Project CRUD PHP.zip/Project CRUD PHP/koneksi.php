<?php
  error_reporting(E_ALL ^ E_DEPRECATED);
  $host = "sql107.epizy.com";
  $user = "epiz_32181669";
  $pass = "tS6gQgZ8nBk";
  $dbName = "epiz_32181669_kursus";

  $kon = mysqli_connect($host,$user,$pass,$dbName);

  if(!$kon)
    die ("Gagal Koneksi");
//    echo "Koneksi Berhasil";
?>